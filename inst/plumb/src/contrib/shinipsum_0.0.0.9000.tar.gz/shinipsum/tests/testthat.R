library(testthat)
library(shinipsum)

test_check("shinipsum")
